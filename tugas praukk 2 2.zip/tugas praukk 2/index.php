<?php session_start(); ?>
<html>

<head>
	<title>Homepage</title>
	<link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

	<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
	</style>
</head>

<body>





	<div class="container-fluid p-4 rounded shadow">
		<?php
		if (isset($_SESSION['valid'])) {
			include("connection.php");
			$result = mysqli_query($mysqli, "SELECT * FROM login");
			?>

			<nav class="navbar navbar-expand-lg bg-body-tertiary">
				<div class="container-fluid" style="background-color: #E9C78C;">
					<?php echo $_SESSION['name'] ?>
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse"
						data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
						aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
						<div class="navbar-nav">
							<a class="nav-link active" aria-current="page" href="index.php"> <b> Home </b> </a>
							<a class="nav-link" href="view.php">View Menu</a>
							<a class="nav-link" href="logout.php">Log Out</a>
						</div>
					</div>
				</div>
			</nav>

			<div class="card">
				<h5 class="card-header" style="background-color: #e3f2fd;">Add New Menus Now!</h5>
				<div class="card-body">
					<h5 class="card-title">Add Your Data</h5>
					<p class="card-text">“A professional is someone who can do his best work when he doesn't feel like it.”
						– Alistair Cooke. </p>
					<a href="add.html" class="btn btn-outline-info me-2">Add</a>
				</div>
			</div>


			<?php
		} else {
			echo "
		<nav class='navbar navbar-expand-lg bg-body-tertiary';'>
  <div class='container-md'  >
    <a class='navbar-brand' href='#'>CRUD</a>
	<form class='container-fluid justify-content-start'>
	<a class= 'btn btn-outline-success me-2' href='login.php'>Login</a>
	<a class='btn btn-sm btn-outline-secondary' href='register.php'>Register</a>
  </form>
  </div>
</nav>
<br>
		";
			echo "
		<div class='buttons'>
		<h4> Welcome To My Page! Please Log In to your account or Register if you don't have one</h4>
		</div>";
		}
		?>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
		</script>
</body>

</html>