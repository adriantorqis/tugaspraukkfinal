<html>

<head>
	<title>Register</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
	<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
</style>

</head>

<body>

	<a class="btn btn-outline-warning me-2" href="index.php">Home</a> <br />
	<?php
	include("connection.php");

	if (isset($_POST['submit'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$user = $_POST['username'];
		$pass = $_POST['password'];

		if ($user == "" || $pass == "" || $name == "" || $email == "") {
			echo "<br/>";

			echo "All fields should be filled. Either one or many fields are empty.";
			echo "<br/>";
			echo "<br/>";
			echo "<br/>";

			echo "<a class= 'btn btn-primary' href='register.php'>Go back</a>";
		} else {
			mysqli_query($mysqli, "INSERT INTO user(name, email, username, password) VALUES('$name', '$email', '$user', md5('$pass'))")
				or die("Could not execute the insert query.");

			echo "Registration successfully";
			echo "<br/>";
			echo "<a href='login.php'>Login</a>";
		}
	} else {
		?>
		<div class="title">
			<p>
				<font style="font-weight: bold;" size="+2">Please Register Your Account!</font>
			</p>
		</div>
		<div class="container">
			<form name="form1" method="post" action="">
				<div class="mb-3">
					<label for="name" class="form-label">Full Name</label>
					<input type="text" class="form-control" name="name">
				</div>
				<div class="mb-3">
					<label for="email" class="form-label">Email</label>
					<input type="text" class="form-control" name="email">
				</div>
				<div class="mb-3">
					<label for="username" class="form-label">Username</label>
					<input type="username" class="form-control" name="username">
				</div>
				<div class="mb-3">
					<label for="password" class="form-label">Password</label>
					<input type="password" class="form-control" name="password">
				</div>
				<input type="submit" class="btn btn-primary" name="submit" value="Submit">
			</form>



		</div>
		<?php
	}
	?>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
		crossorigin="anonymous"></script>

		<script>
			console.log("This Is Adrian's Work");
		</script>

</body>

</html>