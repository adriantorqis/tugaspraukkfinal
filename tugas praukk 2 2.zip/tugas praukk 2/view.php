<?php session_start(); ?>

<?php
if (!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
//including the database connection file
include_once("connection.php");

//fetching data in descending order (lastest entry first)
$result = mysqli_query($mysqli, "SELECT * FROM food WHERE login_id=" . $_SESSION['id'] . " ORDER BY id DESC");
?>

<html>

<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
	<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
</style>
	<title>Homepage</title>
</head>

<body>
	<div class="card">

	<nav class="navbar navbar-expand-lg bg-info-subtle ">
  <div class="container-fluid">
    <a class="nav-link" href="index.php"> Home </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse  " id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="view.php"> <b> View Menu </b></a>
        </li>
    <div class="collapse navbar-collapse  " id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="add.html">Add New Menu</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
        </li>
      </ul>
    </div>
  </div>
</nav>
	</div>

<div class="card mb-3" >
  <div class="row g-0">
    <div class="col-md-4">
      <img src="images/SMKTELKOMSCHJKT.svg.png" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
       <b> <h2 class="card-title">SMK TELKOM JAKARTA</h2> </b>
        <p class="card-text">Tambahkan Data Makanan mu disini!</p>
      </div>
    </div>
  </div>
</div>
	<br /><br />
	<div class="table-data">
	

		<table class="table">
			<thead>
				<tr>
					<th class="text-left" scope="col">Name</th>
					<th class="text-left" scope="col">Category</th>
					<th class="text-left" scope="col">Country</th>
					<th class="text-left" scope="col">Price</th>
					<th class="text-left" scope="col">Update</th>
				</tr>
			</thead>


			<tbody>
				<?php
				while ($res = mysqli_fetch_array($result)) {
					echo "<tr>";
					echo "<td>" . $res['name'] . "</td>";
					echo "<td>" . $res['category'] . "</td>";
					echo "<td>" . $res['country'] . "</td>";
					echo "<td>" . $res['price'] . "</td>";

					echo "<td><a class='btn btn-outline-secondary me-2' href=\"edit.php?id=$res[id]\">Edit</a> | <a class='btn btn-outline-info me-2' href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
				}
				?>

			</tbody>
		</table>

	</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
		crossorigin="anonymous"></script>

</body>

</html>