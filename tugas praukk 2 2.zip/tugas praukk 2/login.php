<?php session_start(); ?>
<html>

<head>
	<title>Login</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
	</style>

</head>

<body>
	<a class="btn btn-outline-primary me-2" href="index.php">Home</a> <br />
	<?php
	include("connection.php");

	if (isset($_POST['submit'])) {
		$user = mysqli_real_escape_string($mysqli, $_POST['username']);
		$pass = mysqli_real_escape_string($mysqli, $_POST['password']);

		if ($user == "" || $pass == "") {
			echo "Either username or password field is empty.";
			echo "<br/>";
			echo "<a href='login.php'>Go back</a>";
		} else {
			$result = mysqli_query($mysqli, "SELECT * FROM user WHERE username='$user' AND password=md5('$pass')")
				or die("Could not execute the select query.");

			$row = mysqli_fetch_assoc($result);

			if (is_array($row) && !empty($row)) {
				$validuser = $row['username'];
				$_SESSION['valid'] = $validuser;
				$_SESSION['name'] = $row['name'];
				$_SESSION['id'] = $row['id'];
			} else {
				echo "Invalid username or password.";
				echo "<br/>";
				echo "<a href='login.php'>Go back</a>";
			}

			if (isset($_SESSION['valid'])) {
				header('Location: index.php');
			}
		}
	} else {
		?>
		<div class="title">
			<p>
				<font style="font-weight: bold;" size="+2">Welcome Back! Please Log In</font>
			</p>
		</div>
		<div class="container">
			<!-- 		
			<form name="form1" method="post" action="">
				<table width="75%" border="0">
					<tr>
						<div class="form-group">
							<td width="10%">Username</td>
							<td><input class="form-control" type="text" name="username"></td>
						</div>
					</tr>
					<tr>
						<div class="form-group">
							<td>Password</td>
							<td><input class="form-control" type="password" name="password"></td>
					</tr>
		</div>
		<tr>
			<td>&nbsp;</td>
			<td><input class="btn btn-danger mt-4" type="submit" name="submit" value="Submit"></td>
		</tr>
		</table>
		</form> -->

			<form name="form1" method="post" action="">
				<div class="mb-3">
					<label for="username" class="form-label">Username</label>
					<input type="text" class="form-control" name="username">

				</div>
				<div class="mb-3">
					<label for="password" class="form-label">Password</label>
					<input type="password" class="form-control" name="password">
				</div>
				<input type="submit" class="btn btn-primary" name="submit" value="Submit">
			</form>
		</div>


		<?php
	}
	?>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">

		</script>

</body>

</html>